import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;
import java.io.File;
import java.io.FileNotFoundException;

public class CheckRandQuality {

    /*
        inserting nodes works, now you just need to write a method to rebalance the tree
        and write code in your main that outputs what the prof wants in the rubric

        also, write more comments, and delete unnessesary shit
    */

    //BST class 
    public static class BST {
        public Node root;
        public String traversal;
        
        //creates an empty binary search tree
        public BST() {
            root = null;
        }


        public class Node {
            public int val;
            public ArrayList<Integer> al = new ArrayList<Integer>();
            public Node parent;
            public Node left;
            public Node right;
            
            //constructors for Nodes
            public Node() {}
            public Node(int v) {
                val = v;
            }
            public Node(int v, ArrayList<Integer> a) {
                val = v;
                al = a;
            }
            public Node(int v,  ArrayList<Integer> a, Node l, Node r) {
                val = v;
                al = a;
                left = l;
                right = r;
            }
        }
        

        //helper classes

        //returns number of nodes in tree at n
        private int size(Node n) {
            if (n == null) {
                return 0; 
            } else {
                if (isLeaf(n)) {
                    return 1;
                } else {
                    return 1 + size(n.left) + size(n.right);
                }
            }
        }

        //returns height of tree at n
        private int height(Node n) {
            if (root == null) {
                return -1;
            }
            //handles a case for math.max comparing a value that doesn't exist
            if (n == null) {
                return 0;
            }
            if (!isLeaf(n)) {
                return 1 + Math.max(height(n.left), height(n.right));
            } else {
                return 0;
            }
        }

        //returns true if n is a leaf
        public boolean isLeaf(Node n) {
            if (n == null) {
                return false;
            } else {
                //returns true if n doesn't have any leaves of its own
                return n.left == null && n.right == null;
            }
        }

        //search method, finds a node with the integer target
        public Node findNode(Node node, int target) {
            //if nonExistent is returned,
            //the node is not in the BST
            if (node == null) {
                Node nonExistent = new Node();
                return nonExistent;
            }
            if (node.val == target) {
                return node;
            }

            Node left = findNode(node.left, target);
            Node right = findNode(node.right, target);

            if (left.val == target) {
                return left;
            }
            if (right.val == target) {
                return right;
            }
            Node nonExistent = new Node();
            return nonExistent;
        }

        //inserts node into BST
        public void insertNode(int i) {
            root = insertNode(root, i);
        }
        public Node insertNode(Node node, int i) {
            if (node == null) {
                ArrayList<Integer> a = new ArrayList<Integer>();
                a.add(insertionOrder);
                node = new Node(i, a);
                insertionOrder++;
                return node;
            }
            if (i > node.val) {
                node.right = insertNode(node.right, i);
                //checks if two child branches have a height
                //difference of more than 1
                if (height(node.right) - height(node.left) > 1) {
                    if (i > node.right.val) {
                        node = rotate(node, "right"); 
                    } else {
                        node = doubleRotate(node, "right");
                    }
                }
            }
            if (i < node.val) {
                node.left = insertNode(node.left, i);
                //checks if two child branches have a height
                //difference of more than 1
                if (height(node.left) - height(node.right) > 1) {
                    if (i < node.left.val) {
                        node = rotate(node, "left");
                    } else {
                        node = doubleRotate(node, "left");
                    }
                }
            }
            //the searched for node already exists
            if (node.val == i) {
                //adds the number of insertions to the ArrayList in the node
                node.al.add(insertionOrder);
                //increments the global variable
                //that keeps track of insertion order
                insertionOrder++;
                return node;
            }
            return node;
        }

        public Node rotate(Node node, String direction) {
            Node temp = null;

            switch (direction) {

                case "left":
                    temp = node.left;
                    node.left = temp.right;
                    temp.right = node;
                    break;

                case "right":
                    temp = node.right;
                    node.right = temp.left;
                    temp.left = node;
                    break;
            }
            return temp;
        }

        public Node doubleRotate(Node node, String direction) {
            switch (direction) {
                case "left":
                    node.left = rotate(node.left, "right");
                    node = rotate(node, "left");
                    break;

                case "right":
                    node.right = rotate(node.right, "left");
                    node = rotate(node, "right");
                    break;
            }
            return node;
        }
    }

    public static int insertionOrder = 1;

    public static void main(String[] args) {
        BST tree = new BST();
        
        //entire main code outside of the BST intializatioon is wrapped in a 
        //try & catch because java needs error handling for file extraction
        //or else the entire program won't run
        try {
            if (args.length > 0) {
                //reads the text file, which should be the first value in args
                Scanner readUserFile = new Scanner(new File(args[0]));

                //adds contents of file to BST
                while (readUserFile.hasNextLine()) {
                    tree.insertNode(readUserFile.nextInt());
                }

                //loops through command line inputted numbers, 
                //i starts at 1 because args[0] should be the text file
                for (int i = 1; i < args.length; i++) {
                    int userNum = Integer.parseInt(args[i]);

                    //takes the number of times the user's requested number shows up in the BST
                    //does this by retrieving the size of the ArrayList containing its indexes in the file
                    int frequency = tree.findNode(tree.root, userNum).al.size();

                    //if frequency is zero, the ArrayList of the Node has no values,
                    //which means it isn't in the BST
                    if (frequency == 0) {
                        System.out.println(userNum + " not found in BST");
                    } else {
                        
                        //this long piece of code turns the ArrayList of the user's requested Node and turns
                        //it into an array, then turns THAT array into a string
                        String insertionOrder = Arrays.toString(tree.findNode(tree.root, userNum).al.toArray());

                        System.out.println(userNum + " appears " + frequency + " times, "
                                            + "order of insertion: " + insertionOrder);
                    }
                }
                readUserFile.close();
            } else {
                System.out.println("please enter a file.");
            }
        } catch (FileNotFoundException e) {
            System.out.println("error, no file found");
            e.printStackTrace();
        }
    }
}