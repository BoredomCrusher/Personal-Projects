import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Comparator;
import java.util.List;

public class FindUsers {
    public static void main(String[] args) {
        try {
            if (args.length > 0) {
                //reads the file in the command line
                Scanner readUserFile = new Scanner(new File(args[0]));

                HashMap<String, Node> nodes = new HashMap<String, Node>();
                ArrayList<String> names = new ArrayList<String>();

                //iterates through the file to initialize nodes in the hashmap,
                //once for every name
                while (readUserFile.hasNextLine()) {
                    String[] splitString = readUserFile.nextLine().split(" ");

                    //if the node with the current name doesn't already exists,
                    //it is created and added to the hashmap
                    //and the ArrayList names now has the name of the new Node.
                    if (nodes.get(splitString[0]) == null) {
                        nodes.put(splitString[0], new Node(splitString[0]));
                        names.add(splitString[0]);
                    }
                    
                }
                //reinitializing the scanner to go through the file again
                readUserFile = new Scanner(new File(args[0]));

                //iterates through the file a second time to add the edges
                //to the neighbor arraylist inside of the initialized nodes
                //inside of the hashmap
                while (readUserFile.hasNextLine()) {
                    String[] splitString = readUserFile.nextLine().split(" ");

                    //converting the weight to double
                    //so the next line isn't incomprehensable
                    Double weight = Double.parseDouble(splitString[2]);

                    //updating neighbors by grabbing values from the hashmap
                    nodes.get(splitString[0]).neighbors.add(new Edge(nodes.get(splitString[1]), weight));
                }

                ArrayList<Node> revisedNodes = new ArrayList<Node>();

                //puts the contents of the hashmap into an arraylist for simpler
                //implimentation later for the shortest path algoritm
                for(int i = 0; i < names.size(); i++) {
                    revisedNodes.add(nodes.get(names.get(i)));
                }

                //identifies if the third argument 
                //is targetPerson or seperationScore
                String identifier = args[2].substring(0,2);

                //decides whether to find the distance to a node or find all nodes
                //greater than, less than, or equal to the initial node
                if (identifier.equals("eq") || identifier.equals("lt") || identifier.equals("gt")) {
                    int seperationScore = Integer.parseInt(args[2].substring(2));

                    //calls the shortest path method with a hashmap for the initial node
                    //to immediately find the node typed into the command line
                    DijkstraShortestPath(nodes.get(args[1]), revisedNodes);

                    //output string to add to with results of the switch statement
                    String result = "";

                    switch (identifier) {
                        
                        //if the target value is equal to the distance
                        case "eq":
                        result = " equal to " + seperationScore + " : ";
                        for (int i = 0; i < revisedNodes.size(); i++) {
                            if (revisedNodes.get(i).distance == Double.valueOf(seperationScore)){
                                result += revisedNodes.get(i).name + " ";
                            }
                        }
                        break;

                        //if the target value is lesser than the distance
                        case "lt":
                        result = " lesser than " + seperationScore + " : ";
                        for (int i = 0; i < revisedNodes.size(); i++) {
                            //test case excluding the starting node 
                            //from the lesser than search
                            if (revisedNodes.get(i).distance == 0.0) {
                                continue;
                            }
                            if (revisedNodes.get(i).distance < Double.valueOf(seperationScore)){
                                result += revisedNodes.get(i).name + " ";
                            }
                        }
                        break;

                        //if the target value is greater than the distance
                        case "gt":
                        result = " greater than " + seperationScore + " : ";
                        for (int i = 0; i < revisedNodes.size(); i++) {
                            if (revisedNodes.get(i).distance > Double.valueOf(seperationScore)){
                                result += revisedNodes.get(i).name + " ";
                            }
                        }
                        break;

                    }

                    //if the above switch statement added nothing to the output
                    //in other words, if there are no nodes in range of the user's request
                    if (result.substring(result.length()-2).equals(": ")) {
                        result += "none";
                    }

                    System.out.println(args[1] + result);

                } else {
                    int initialPerson = 0;
                    int targetPerson = 0;

                    //finding the indexes of the starting node and the
                    //target node for the node arraylist
                    for (int i = 0; i < revisedNodes.size(); i++) {
                        if (revisedNodes.get(i).name.equals(args[1])) {
                            initialPerson = i;
                        }
                        if (revisedNodes.get(i).name.equals(args[2])) {
                            targetPerson = i;
                        }
                    }

                    DijkstraShortestPath(revisedNodes.get(initialPerson), revisedNodes);

                    //test case for if the target node cannot be accessed by the initial node
                    if (revisedNodes.get(targetPerson).distance == Integer.MAX_VALUE) {
                        System.out.println(args[1] + " -> " + args[2] + " : " + "infinity");
                        
                    } else {
                        System.out.println(args[1] + " -> " + args[2] + " : " + revisedNodes.get(targetPerson).distance);
                    }
                    
                }

            } else {
                //if the command line is empty
                System.out.println("Please enter a file");
            }
        } catch (FileNotFoundException e) {
            //if there is no file in the command line
            System.out.println("Error, no file found.");
            e.printStackTrace();
        }
    }

    public static void DijkstraShortestPath(Node startingVertex, ArrayList<Node> nodesGraph) {
        PriorityQueue<Node> unvisitedQueue = new PriorityQueue<Node>();
        Node currentVertex;

        for (int i = 0; i < nodesGraph.size(); i++) {
            currentVertex = nodesGraph.get(i); 
            currentVertex.distance = Integer.MAX_VALUE;
            currentVertex.predV = null;
            unvisitedQueue.add(currentVertex);
        }

        //startingVertex has a distance of 0 to begin with
        startingVertex.distance = 0;

        //while the unvisited queue is not empty
        while (!unvisitedQueue.isEmpty()) {

            currentVertex  = unvisitedQueue.poll();

            for (int j = 0; j < currentVertex.neighbors.size(); j++) {
                Node adjacentVertex = currentVertex.neighbors.get(j).dest;

                double edgeWeight = currentVertex.neighbors.get(j).weight;
                double alternativePathDistance = currentVertex.distance + edgeWeight;

                //if a shorter path from startingVertex to adjacentVertex is found,
                //update adjacentVertex's distance and predecessor
                if (alternativePathDistance < adjacentVertex.distance) {
                    adjacentVertex.distance = alternativePathDistance;
                    adjacentVertex.predV = currentVertex;
                }
            }
        }
    }

    public static class Node implements Comparable<Node> {
        //has to be implimented for the priority queue to work
        //in the shortest path algorhythm
        public int compareTo(Node n) {
            if (this.distance < n.distance) {
                return -1;
            }  else if (this.distance > n.distance) {
                return 1;
            } else {
                return 0;
            }
        }
        
        String name;
        double distance;
        Node predV;
        ArrayList<Edge> neighbors;
        public Node (String name) {
            this.name = name;
            neighbors = new ArrayList<Edge>();
        }
    }

    public static class Edge {
        Node dest;
        double weight;
        public Edge(Node dest, double weight) {
            this.dest = dest;
            this.weight = weight;
        }
    }
}