/* ExceptionLab.java
 * 
 * A simple class that triggers various exceptions.
 *
 * In the CSCI 241 Exception Handling Lab, you will modify this code to
 * catch these exceptions.
 *
 * Usage:
 *
 * java ExceptionLab x1 x2 .. xN
 *
 * where each xi are integers
 *
 */

import java.util.Arrays;
import java.io.FileNotFoundException;
import java.lang.NumberFormatException;
import java.lang.ArithmeticException;
import java.lang.ArrayIndexOutOfBoundsException;
import java.lang.NullPointerException;

class ExceptionLab {
    // define constants to avoid "magic numbers" later in the code
    private static final int sliceLower = 3; // lower bound on array slice
    private static final int sliceUpper = 8; // upper bound on array slice
    private static final String out_fn = ".tmp.lab5.txt"; // output filename

    // Perform a series of (contrived) operations on the args array 
    public static void main(String[] args) {
        int[] x = null;
        try {
        // convert string array to int array
            x = makeArray(args);
            System.out.println(Arrays.toString(x));
        

        // convert int array to itself in an artificial/strange way
            x = identity(x);
            System.out.println(Arrays.toString(x));
        } catch (java.lang.NumberFormatException e) {
            System.out.println("makeArray threw exception: " + e);
            System.exit(1);
        } catch (java.lang.ArithmeticException e) {
            System.out.println("identity threw exception: " + e);
            System.exit(1);
        }
        
        // retrieve just elements from index sliceLower (inclusive)
        // to sliceUpper (exclusive)
        try { 
            int[] s = slice(x,sliceLower,sliceUpper);
            System.out.println(Arrays.toString(s));
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
            System.out.println("slice threw execption: " + e);
        }

        // like slice but flat out broken
        try {
            int[] s2 = buggierSlice(x,sliceLower,sliceUpper);
            System.out.println(Arrays.toString(s2));
        } catch (java.lang.NullPointerException e) {
            System.out.println("buggierSlice threw exception: " + e);
        }

        //write array x to out_fn
        try {
            writeArrayToFile(x,out_fn);
        } catch (java.io.FileNotFoundException e) {
            System.out.println("writeArrayToFile threw exception: " + e);
        }

        return;
    }

    //NumberFormatExceptipon error
    private static int[] makeArray(String[] args) throws NumberFormatException {
        int[] result = new int[args.length];
        for( int i=0; i<args.length; i++ ) {
            result[i] = Integer.parseInt(args[i]);
        }
        return result;
    }

    //ArithmeticException  error
    private static int[] identity(int[] x) throws ArithmeticException {
        int[] result = new int[x.length];
        for( int i=0; i<x.length; i++ ) {
            result[i] = (x[i]*x[i])/x[i];
        }
        return result;
    }

    //ArrayIndexOutOfBounds error
    private static int[] slice(int[] x, int startIdx, int endIdx ) throws ArrayIndexOutOfBoundsException {
        int[] result = new int[endIdx-startIdx];

        for( int i=startIdx; i<endIdx; i++ ) {
            result[i-startIdx] = x[i];
        }

        return result;
    }

    //NullPointerException
    private static int[] buggierSlice(int[] x, int startIdx, int endIdx ) throws NullPointerException {
        int[] result = null;

        for( int i=startIdx; i<endIdx; i++ ) {
            result[i-startIdx] = x[i];
        }

        return result;
    }

    
    private static void writeArrayToFile(int[] x, String fn) throws java.io.FileNotFoundException {
        java.io.File        outFile = new java.io.File(fn);
        java.io.PrintStream out     = new java.io.PrintStream(outFile);
        for( int i=0; i<x.length; i++ ) {
            out.println(Arrays.toString(x));
        }
    }
    

}
