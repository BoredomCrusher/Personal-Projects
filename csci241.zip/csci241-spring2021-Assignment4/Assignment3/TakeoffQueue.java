import java.util.Arrays;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class TakeoffQueue {
    public static void main(String[] args) {
        try {
            Plane[] planes = new Plane[25];
            int planeCounter = 0;

            if (args.length > 0) {
                
                //reads the text file, which should be the first value in args
                Scanner readUserFile = new Scanner(new File(args[0]));
                //reads the schedule number from the command line
                String scheduleNumber = args[1];

                //adds contents of the entire file 
                String entireFile = "";

                //adds contents of file to BST
                while (readUserFile.hasNextLine()) {
                    //reads contents of file as strings
                    
                    entireFile = readUserFile.nextLine();

                    String[] splitString = entireFile.split(" ");

                    //deals with the colon in the requested departure time
                    String[] dealWithTheColon = splitString[3].split(":");
                    splitString[3] = dealWithTheColon[0] + dealWithTheColon[1];

                    //initializes individual depature statements in the array
                    planes[planeCounter] = new Plane(splitString[0], Integer.parseInt(splitString[4]), Integer.parseInt(splitString[3]));
                    //increments number of planes
                    planeCounter++;
                }
                readUserFile.close();

                switch (scheduleNumber) {
                    
                    case "1":
                    //--------------works perfectly except it tries to remove from a heap with no elements 13 times-------
                    String[] outputOne = scheduleOne(planes);

                    for (int i = outputOne.length - 1; i >=0; i--) {
                        if (outputOne[i] != null) {
                            System.out.println(outputOne[i]);
                        }
                    }

                    break;

                    case "2":
                    //--------------works perfectly except it tries to remove from a heap with no elements 13 times-------
                    String[] outputTwo  = scheduleTwo(planes);
                    for (int i = 0; i < outputTwo.length; i += 2) {
                        if (outputTwo[i] != null) {
                            System.out.println(outputTwo[i] + " " + outputTwo[i + 1]);
                        }
                    }
                    break;

                    case "3":
                    scheduleThree();
                    break;
                }
            } else {
                System.out.println("please enter a file.");
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error, no file found.");
            e.printStackTrace();
        }
    }
     
            public static String[] scheduleOne(Plane[] allPlanes) {
                //returns the plane names in order of first requests
                HeapMax h = new HeapMax(25);

                for (Plane planeSearch : allPlanes) {
                    if (planeSearch != null) {
                        h.insert(planeSearch.takeoff);
                    } else {
                        break;
                    }
                    
                }

                String[] output = new String[25];
                int outputIndex = 0;

                while (h.extractMax() != 0) {
                    for (Plane planeSearch : allPlanes) {
                        if (planeSearch != null) {
                            if (planeSearch.takeoff == h.extractMax()) {
                                h.removeMax();
                                output[outputIndex] = planeSearch.planeNum;
                                outputIndex++;
                            }
                        }
                    }
                } 
                return output;
            } 

            public static String[] scheduleTwo(Plane[] allPlanes) {
                //returns the plane names and passenger numbers 
                //in order of most passengers
                HeapMax h = new HeapMax(25);

                for (Plane planeSearch : allPlanes) {
                    if (planeSearch != null) {
                        h.insert(planeSearch.passengers);
                    } else {
                        break;
                    }
                    
                }

                String[] output = new String[50];
                int outputIndex = 0;

                while (h.extractMax() != 0) {
                    for (Plane planeSearch : allPlanes) {
                        if (planeSearch != null) {
                            System.out.println("max plane " + h.extractMax());
                            System.out.println("current plane: " + planeSearch.takeoff);
                            if (planeSearch.passengers == h.extractMax()) {
                                h.removeMax();
                                output[outputIndex] = planeSearch.planeNum;
                                output[outputIndex + 1] = Integer.toString(planeSearch.passengers);
                                outputIndex += 2;
                            
                            }
                        }
                    }
                } 
                return output;
            }

            public static String[] scheduleThree() {
                //returns '<plane name> departed at <takeoff time>'
                //based on count of passengers and requested takeoff time

                /*
                Scheme 3 also takes into account the request time 
                AND the amount of time that an airplane needs to takeoff 
                once permission has been granted. 
                The time to takeoff once permission is granted is

                [takeoffTime = NumPassengers/2]

                where / is the integer division operator. 
                The value takeoffTimeis ceiling rounded (next highest) to a multiple of 60. 
                The units areseconds. For example,if the number of passengers is 164, 
                then takeoff time is 164 / 2 = 82, 
                which ceiling rounds to 120, which is 2 minutes

                -------------------------------------------------------------------------------------------

                In this scenario, the time that it takes an airplane to take off is also taken into account, 
                which may or may not induce an airplane at the top of the min-heap to have to wait to take off. 
                While planes are waiting to take off, a NEW takeoff request might be received, which would cause the min-heap to be reordered. 
                The output is the order  of  takeoffs  and  their  times.  
                This  (full  prioritization)  is  the  extra  credit  portion  of  this assignment.

                */ 
                String[] placeholder = new String[10];
                return placeholder;
            }

    public static class Plane {
        
        String planeNum;
        int passengers;
        int takeoff;
        public Plane(){}
        public Plane(String planeNumber, int passengerNumber, int takeOffTime) {
            planeNum = planeNumber;
            passengers = passengerNumber;
            takeoff = takeOffTime;
        }
    }

    public static class HeapMax {
        public int currentSize = 0;
        public int[] heap;
        
        public HeapMax(int size) {
            //cautionary test case for if the heap is empty
            if (size <= 0) {
                size = 1;
            }
            heap = new int[size + 1];
            //the first index is max_value so that i can basically start the index at 1 for the heap
            //this is to make finding the root much easier with later math
            //so that the root doesn't need its own cases and can be treated like any other index
            //as long as it exists and has not been removed
            heap[0] = Integer.MAX_VALUE;
        }

        //returns the index of the current index's parent
        private int parentIndex(int index) {
            return index / 2;
        }
        //returns the index of the current index's left child
        private int leftChildIndex(int index) {
            return 2 * index;
        }
        //returns the index of the current index's right child
        private int rightChildIndex(int index) {
            return 2 * index + 1;
        }

        public void insert(int element) {
            //inserts value into heap

            currentSize++;

            if (currentSize >= heap.length) {
                System.out.println("The heap is full and cannot take any more elements.");
                currentSize -= 1;
                return;
            }
            
            //insert element into heap at child position
            heap[currentSize] = element;
            int current = currentSize;

            //swap position of inserted element while it is not in the right place
            while (heap[current] > heap[parentIndex(current)]) {
                int temp;
                temp = heap[current];
                heap[current] = heap[parentIndex(current)];
                heap[parentIndex(current)] = temp;
                current = parentIndex(current);
            }
        }

        public int extractMax() {
            //returns root element of the max heap
            if (heap[1] != 0) {
                return heap[1];
            } else {
                //senario when there are no elements in the heap
                //System.out.println("the heap has no elements");
                return 0;
            }
        }

        public int removeMax() {
            //removes and returns the root element of the max heap and reorganizes the
            //heap accordingly to restore its max heap characteristics

            //senario when there are no elements in the heap
            if (heap[1] == 0) {
                System.out.println("the heap has no elements");
                return 0;
            }

            int previousRoot = heap[1];

            //swaps root with smallest element in heap
            heap[1] = heap[currentSize];
            currentSize--;
            
            int i = 1;
            //while the current index is not a leaf
            while (!(i > (currentSize/2) && i <= currentSize)) {
                //checks if the current index is less than either child
                if (heap[i] < heap[leftChildIndex(i)] || heap[i] < heap[rightChildIndex(i)]) {
                    //checks which child is larger
                    if (heap[leftChildIndex(i)] > heap[rightChildIndex(i)]) {
                        //swaps the current index with the left child
                        int temp;
                        temp = heap[i];
                        heap[i] = heap[leftChildIndex(i)];
                        heap[leftChildIndex(i)] = temp;

                        //makes the left child the index for the next loop
                        i = leftChildIndex(i);
                    } else {
                        //swaps the current index with the right child
                        int temp;
                        temp = heap[i];
                        heap[i] = heap[rightChildIndex(i)];
                        heap[rightChildIndex(i)] = temp;

                        //makes the right child the index for the next loop
                        i = rightChildIndex(i);
                    }
                } 
                else {
                    break;
                }
            }
            //deletes previous value that was initially 
            //swapped with the root before the while loop
            heap[currentSize + 1] = 0;

            //returns the original root
            return previousRoot;
        }

        public void display() {
            //prints all elements in the max heap in the order of levels (root, root children, etc)

            //keeps track of the current heap level in the for loop
            int levelCap = 2;

            System.out.println("\nCurrent heap is: ");

            //loop starts at 1 because my heap starts at index 1
            for (int i = 1; i < heap.length; i++) {
                //makes the loop skip over empty spaces
                //in the heap
                if (heap[i] == 0) {
                    continue;
                }

                System.out.print(heap[i]);

                //elements on the same level should be seperate with one or two white spaces
                //elements on different levels should be seperated with a comma
                if (i == levelCap - 1) {
                    System.out.print(", ");
                    levelCap *= 2;
                } else {
                    System.out.print(" ");
                }
            }   
        }
    }
}