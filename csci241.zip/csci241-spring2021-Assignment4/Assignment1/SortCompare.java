import java.util.Scanner;
import java.util.Random;

public class SortCompare {

    /*
        instead of hardcoding printing out the array & shit inside of the switch statement,
        change it so that it outputs everything inside of the sort methods
        so you can just call the methods inside of the switch statement and that's it

        it would be a hell of a lot less messy to look at, and a hell of a lot less messy to bugfix 
    */

    public static Scanner scanner = new Scanner(System.in);
    public static Random rand = new Random();

    public static void main(String[] args) {
        System.out.println("Please enter the size of the array: ");

        //creates an int array the size of the user input
        int[] userArray = new int[scanner.nextInt()];

        for (int i = 0; i < userArray.length; i++) {
            //generates number between the negative value of the userArray length
            //and the positive value of the userArray length
            userArray[i] = rand.nextInt(userArray.length*2) - userArray.length;
        }

        System.out.println("Would you like to use: \n" + "m.) merge sort\n" +
            "q.) quick sort\n" + "i.) insertion sort\n" + "r.) radix sort\n" + 
            "a.) all of them at once");

        //avoids a buffer error
        scanner.nextLine();

        //accepts input from user for sort selection
        String userInput = scanner.nextLine();
        
        switch(userInput.toLowerCase()) {
            case "m":
            System.out.println("merge sort placeholder");
            break;

            case "q":
            System.out.println("quick sort placeholder");
            break;

            case "i":
            System.out.println("Merge Sort \n" + "----------");
            if (userArray.length < 20) {
                System.out.println("Unsorted array:");

                //prints out unsorted user array
                for (int i : userArray) {
                    System.out.print("" + i + ", ");
                }
                
                //calls insertionSort
                insertionSort(userArray);

                System.out.println("\nNum Comparisons: code this in, the directions are in the rubric");

                System.out.println("Sorted array:");
                for (int i : userArray) {
                    System.out.print("" + i + ", ");
                }

                //makes sure the last line printed doesn't get hidden by the command line in a terminal
                System.out.print("\n");
            } else {
                insertionSort(userArray);

                System.out.println("Num Comparisons: idk how tf to do this yet");
            }
            break;
            
            case "r":
            System.out.println("radix sort placeholder");
            break;
            
            //make sure to code this
            case "a":
            System.out.println("all sorts placeholder");
            break;
        }
    }

    public static int[] insertionSort(int[] array) {
            //test case for a length 2 array that probably doesn't need to exist
            if (array.length == 2) {
                    int[] testCasearray = {array[1],array[0]};
                    return testCasearray;
                }
            // loop starts at 1 to prevent outOfBounds Error
            for (int i = 1; i < array.length; i++) {
                int current = array[i];
                int previous = i-1;
                //loop runs as long as previous hasn't gone past the start of the array
                //and the currently compared index is greater than the current element
                while (previous >= 0 && array[previous] > current) {
                    array[previous + 1] = array[previous];
                    //iterates backwards to start of array
                    previous--;
                }
                //finally sorts the for loop's current element
                array[previous + 1] = current;
            }
            //returns sorted array
            return array;
    }
}