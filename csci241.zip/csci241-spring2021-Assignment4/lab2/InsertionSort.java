public class InsertionSort {
    public static int[] insertionSort(int[] arr) {
            //test case for a length 2 array that probably doesn't need to exist
            if (arr.length == 2) {
                    int[] testCaseArr = {arr[1],arr[0]};
                    return testCaseArr;
                }
            // loop starts at 1 to prevent outOfBounds Error
            for (int i = 1; i < arr.length; i++) {
                int current = arr[i];
                int previous = i-1;
                //loop runs as long as previous hasn't gone past the start of the array
                //and the currently compared index is greater than the current element
                while (previous >= 0 && arr[previous] > current) {
                    arr[previous + 1] = arr[previous];
                    //iterates backwards to start of array
                    previous--;
                }
                //finally sorts the for loop's current element
                arr[previous + 1] = current;
            }
            //returns sorted array
            return arr;
        }
    }