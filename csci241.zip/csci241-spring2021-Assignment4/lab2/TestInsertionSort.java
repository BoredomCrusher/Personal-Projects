import java.util.Arrays;
import java.util.Scanner;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

public class TestInsertionSort {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
       // checks for command line arguments 
       if (args.length != 0) {
           // if there are command line arguments, they are parsed into ints
           // and run with shuffleTest
           for (String i : args) {
               shuffleTest(Integer.parseInt(i));
           }
       } else {
           // runs testFromConsole if no command line arguments are entered
           testFromConsole();
       }

    }

    public static boolean isSorted(int[] arr) {
        // code compares every int in arr to check if the array
        // is in ascending order
        boolean ascendingOrder = true;

        // loop ends at length - 2 to prevent an outOfBounds error
        for (int i = 0; i < arr.length - 2; i++) {
            if (arr[i] > arr[i + 1]) {
                ascendingOrder = false;
            }
        }
        return ascendingOrder;
    }

    public static boolean sameElements(int[] Arr1, int[] Arr2) {
        // test case to make sure both arrays are the same length
        if (Arr1.length != Arr2.length) {
            return false;
        }

        // creating one hashmap for each array inputted by user
        HashMap<Integer, Integer> Arr1HashMap = new HashMap<Integer, Integer>();
        HashMap<Integer, Integer> Arr2HashMap = new HashMap<Integer, Integer>();

        // one for loop for each hashmap to input each number from the int arrays
        for (int i : Arr1) {
            if (Arr1HashMap.containsKey(i)) {
                Arr1HashMap.put(i, Arr1HashMap.get(i) + 1);
            } else {
                Arr1HashMap.put(i, 1);
            }
        }

        for (int x : Arr2) {
            if (Arr2HashMap.containsKey(x)) {
                Arr2HashMap.put(x, Arr2HashMap.get(x) + 1);
            } else {
                Arr2HashMap.put(x, 1);
            }
        }

        // returns whether or not the hashmaps are equal
        return Arr1HashMap.equals(Arr2HashMap);
    }

    private static void testFromConsole() {
        // retrieves number of expected inputs from user
        System.out.println("How many inputs will you be entering?");
        int inputNumber = scanner.nextInt();

        // creates int arrays the length of expected user inputs
        // userNumbers is sorted later, preSortedUserArray isn't
        int[] userNumbers = new int[inputNumber];
        int[] preSortedUserArray = new int[inputNumber];

        // adds user inputs to created int arrays
        for (int i = 0; i < inputNumber; i++) {
            // (i + 1) is to show user the current input in the print statement
            System.out.println("Please enter input number " + (i + 1));
            userNumbers[i] = preSortedUserArray[i] = scanner.nextInt();
        }

        
        // sorts the user's array with InsertionSort
        InsertionSort.insertionSort(userNumbers);

        // if both sameElements and isSorted return true, print true
        // else print false

        if (isSorted(userNumbers) && sameElements(userNumbers, preSortedUserArray)) {
            System.out.println("true");
        } else {
            System.out.println("false");
        }

    }

    private static void shuffleTest(int N) {
        // generates two int arrays of length n containing the elements 0...n-1
        // in ascending order
        // intArr will be shuffled, savedUserArr will not

        int[] intArr = new int[N];
        int[] savedUserArr = new int[N];
        for (int i = 0; i < N; i++) {
            savedUserArr[i] = i;
            intArr[i] = i;
        }

        // briefly converts the user's array into a list to use Collections.shuffle()
        List<Integer> tempList = new ArrayList<>();
        for (int i : intArr) {
            tempList.add(i);
        }
        // randomly shuffles array
        Collections.shuffle(tempList);

        // converts list back into an array
        for (int x = 0; x < tempList.size(); x++) {
            intArr[x] = tempList.get(x);
        }

        // uses insertSort to sort the shuffled array
        InsertionSort.insertionSort(intArr);

        // compares output of insertionSort to original ascending array
        // if the sorted array equals the orginal array, print "PASSED Test",
        // else print "FAILED Test"

        if (Arrays.equals(intArr, savedUserArr)) {
            System.out.println("PASSED Test");
        } else {
            System.out.println("FAILED Test");
        }
    }
}