import java.util.Random;
public class HeapMaxTest {
    //create at least three examples "covering varied senarios"
    //in each example you will need to preform multiple insertions and deletions
    //after you will need to call the display method to confirm

    public static void main(String[] args) {
        //creates examples with randomly generated heap & removals
        //with a length of heap 5
        randHeap();
        randHeap();
        randHeap();
    }

    public static Random rand = new Random();

    public static void randHeap() {
        HeapMax h = new HeapMax(5);

        System.out.println("\n\n------Testing begins-------");

        for (int i = 0; i < 5; i++) {
            int newNum = rand.nextInt(50);

            System.out.println("\n\ninserting " + newNum);

            h.insert(newNum);
            h.display();

            //one in five chance that the code will
            //run removeMax on the heap
            if (rand.nextInt(5) == 1) {
                System.out.println("\n\nremove max");
                h.removeMax();
                h.display();
            }
        }

        System.out.println("\n\n------Testing ends------");
    }
}