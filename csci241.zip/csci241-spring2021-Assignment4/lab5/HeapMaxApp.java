public class HeapMaxApp {
    public static int kthBiggest(int[][] matr, int k) {
        HeapMax heap = new HeapMax((int)Math.pow(matr.length, 2));

        //inserting all elements of the matrix into the heap
        for (int i = 0; i < matr.length; i++) {
            for (int j = 0; j < matr[0].length; j++) {
                heap.insert(matr[i][j]);
            }
        }

        int output = 0;
        //removing the largest value k times
        while (k > 0) {
            output = heap.removeMax();
            k--;
        }
        return output;
    }

    public static void main(String[] args) {
        int[][] exampleArray = {{1,5,9},{10,11,13},{12,13,15}};
        int k = 3;

        System.out.println("Testing of kthBiggest starts\nThe given matrix is\n");
        //prints example matrix
        for (int i = 0; i < exampleArray.length; i++) {
            for (int j = 0; j < exampleArray[0].length; j++) {
                System.out.print(exampleArray[i][j] + ",");
            }
            //puts a space between levels of the matrix
            System.out.println();
        }

        System.out.println("\nthe " + k + "rd biggest element is " + kthBiggest(exampleArray, k));
        System.out.println("Testing of kthBiggest ends");
    }
    
}