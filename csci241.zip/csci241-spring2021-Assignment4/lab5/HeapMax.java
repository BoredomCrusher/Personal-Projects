public class HeapMax {
    public int currentSize = 0;
    public int[] heap;
    
    public HeapMax(int size) {
        //cautionary test case for if the heap is empty
        if (size <= 0) {
            size = 1;
        }
        heap = new int[size + 1];
        //the first index is max_value so that i can basically start the index at 1 for the heap
        //this is to make finding the root much easier with later math
        //so that the root doesn't need its own cases and can be treated like any other index
        //as long as it exists and has not been removed
        heap[0] = Integer.MAX_VALUE;
    }

    //returns the index of the current index's parent
    private int parentIndex(int index) {
        return index / 2;
    }
    //returns the index of the current index's left child
    private int leftChildIndex(int index) {
        return 2 * index;
    }
    //returns the index of the current index's right child
    private int rightChildIndex(int index) {
        return 2 * index + 1;
    }

    public void insert(int element) {
        //inserts value into heap

        currentSize++;
        
        //insert element into heap at child position
        heap[currentSize] = element;
        int current = currentSize;

        //swap position of inserted element while it is not in the right place
        while (heap[current] > heap[parentIndex(current)]) {
            int temp;
            temp = heap[current];
            heap[current] = heap[parentIndex(current)];
            heap[parentIndex(current)] = temp;
            current = parentIndex(current);
        }
    }

    public int extractMax() {
        //returns root element of the max heap
        if (heap[1] != 0) {
            return heap[1];
        } else {
            //senario when there are no elements in the heap
            System.out.println("the heap has no elements");
            return 0;
        }
    }

    public int removeMax() {
        //removes and returns the root element of the max heap and reorganizes the
        //heap accordingly to restore its max heap characteristics

        //senario when there are no elements in the heap
        if (heap[1] == 0) {
            System.out.println("the heap has no elements");
            return 0;
        }

        int previousRoot = heap[1];

        //swaps root with smallest element in heap
        heap[1] = heap[currentSize];
        currentSize--;
        
        int i = 1;
        //while the current index is not a leaf
        while (!(i > (currentSize/2) && i <= currentSize)) {
            //checks if the current index is less than either child
            if (heap[i] < heap[leftChildIndex(i)] || heap[i] < heap[rightChildIndex(i)]) {
                //checks which child is larger
                if (heap[leftChildIndex(i)] > heap[rightChildIndex(i)]) {
                    //swaps the current index with the left child
                    int temp;
                    temp = heap[i];
                    heap[i] = heap[leftChildIndex(i)];
                    heap[leftChildIndex(i)] = temp;

                    //makes the left child the index for the next loop
                    i = leftChildIndex(i);
                } else {
                    //swaps the current index with the right child
                    int temp;
                    temp = heap[i];
                    heap[i] = heap[rightChildIndex(i)];
                    heap[rightChildIndex(i)] = temp;

                    //makes the right child the index for the next loop
                    i = rightChildIndex(i);
                }
            } 
            else {
                break;
            }
        }
        //deletes previous value that was initially 
        //swapped with the root before the while loop
        heap[currentSize + 1] = 0;

        //returns the original root
        return previousRoot;
    }

    public void display() {
        //prints all elements in the max heap in the order of levels (root, root children, etc)

        //keeps track of the current heap level in the for loop
        int levelCap = 2;

        System.out.println("\nCurrent heap is: ");

        //loop starts at 1 because my heap starts at index 1
        for (int i = 1; i < heap.length; i++) {
            //makes the loop skip over empty spaces
            //in the heap
            if (heap[i] == 0) {
                continue;
            }

            System.out.print(heap[i]);

            //elements on the same level should be seperate with one or two white spaces
            //elements on different levels should be seperated with a comma
            if (i == levelCap - 1) {
                System.out.print(", ");
                levelCap *= 2;
            } else {
                System.out.print(" ");
            }
        }   
    }
}