#include <stdio.h>
#include <stdarg.h>
int myLogFun(const char* input, ...) {
    va_list ap;
    va_start(ap, input);
    vprintf(input, ap);
}