/* This program reads a line from the console, verifies that it contains a
 * sequence of unsigned integers, and that those integers are the beginning of a
 * specific mathematical sequence.  The program succeeds if the string matches,
 * otherwise, it reports the error and returns failure.
 *
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Matches
 * Returns true if line is a sequence of unsigned that matches the beginning of
 * a specific, infinite, mathematical sequence.
 * 
 * the sequence is the first six digits of pi  
 */

bool recurseMatches(char* line, int* pi, int currentIntegerLength, char* pi_check);

bool matches(char* line) {
  int pi[6] = {3, 1, 4, 1, 5, 9};
  char* pi_check = strtok(line, " ");
  int currentIntegerLength = 0;

  return recurseMatches(line, pi, currentIntegerLength, pi_check);
}

bool recurseMatches(char* line, int* pi, int currentIntegerLength, char* pi_check) {
  //base case.
  if (currentIntegerLength == 6)
    return true;

  int x;
  
  sscanf(pi_check, "%d", &x);
  if (x != pi[currentIntegerLength]) {
    return false;

  } else {
    pi_check = strtok(NULL, " ");
    currentIntegerLength++;
    
    return recurseMatches(line, pi, currentIntegerLength, pi_check);
  }
}


/* Main
 * Returns success if the input string matches (above).  Otherwise, it returns
 * failure.  
 *
 * There are really two failure modes: gitline falure, input mismatch.  In the
 * former case, perror is used to display the error condition set by getline.
 * In the latter case, the a brief error message is printed.  
 *
 * Note the if-statement that removes the trailing new-line.  The last character
 * from getline does not have to be a new-line, so the if-statement is
 * required.  
 */
// Do not modify this function!
int main() {
  bool   isSuccess = false;
  char*  line = NULL;
  size_t size = 0;
  ssize_t len = getline(&line, &size, stdin);

  if(-1 == len) {
    perror("getline");
  }
  else {
    
    if(line[len-1] == '\n') {
      line[len-1] = '\0';
    }
       
    isSuccess = matches(line);

    if(!isSuccess) {
      printf("Didn't match\n");
    }

    free(line);
  }

  return isSuccess ? EXIT_SUCCESS : EXIT_FAILURE;
}
