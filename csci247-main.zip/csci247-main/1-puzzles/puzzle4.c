/* This program reads a line from the console and verifies that it matches the
 * encrypted form of a string literal.  The cipher used is a simple
 * substitution, which is held as a constant character array.  The program
 * succeeds if the string matches, otherwise, it reports the error and returns
 * failure.
 *
 * Unlike true encryption, spaces, punctuation, and capitalization are
 * preserved.  
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* Encrypt
 * This function runs the substitution cipher in-place.  That is, line is
 * modified.
 * 
 * [line[i] / 5 - 13] on line 45 reduces the index number low enough 
 * to be found in my char array cipher (1-13)
 */

void encrypt(char* line) {
  char* cipher = "quoththeraven";

  for (int i = 0; i < strlen(line); i++) {
    if (isalpha(line[i]) && isupper(line[i])) {
      line[i] = cipher[line[i] / 5 - 13];
      line[i] = toupper(line[i]);

    } else if (isalpha(line[i])) {
      line[i] = cipher[line[i] / 5 - 13];
    }
  }
}

/* Matches
 * Returns true if line is the encrypted form of the string literal.  
 * 
 * the expected input is "quoth the raven"
 * the same as the cipher (except with spaces between the words)
 */
bool matches(char* line) {
  encrypt(line);
  
  return strcmp(line, "avave vee ahvea") == 0;
}


/* Main
 * Returns success if the input string matches (above).  Otherwise, it returns
 * failure.  
 *
 * There are really two failure modes: gitline falure, input mismatch.  In the
 * former case, perror is used to display the error condition set by getline.
 * In the latter case, the a brief error message is printed.  
 *
 * Note the if-statement that removes the trailing new-line.  The last character
 * from getline does not have to be a new-line, so the if-statement is
 * required.  
 */
// Do not modify this function!
int main() {
  bool   isSuccess = false;
  char*  line = NULL;
  size_t size = 0;
  ssize_t len = getline(&line, &size, stdin);

  if(-1 == len) {
    perror("getline");
  }
  else {
    
    if(line[len-1] == '\n') {
      line[len-1] = '\0';
    }
       
    isSuccess = matches(line);

    if(!isSuccess) {
      printf("Didn't match\n");
    }

    free(line);
  }

  return isSuccess ? EXIT_SUCCESS : EXIT_FAILURE;
}
